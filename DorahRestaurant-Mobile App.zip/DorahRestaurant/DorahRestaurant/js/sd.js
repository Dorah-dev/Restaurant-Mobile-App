$scope.currSel = null;
$scope.metadata = [
    { proc: "Proc-1", board: "Alloc" },
    { proc: "Proc-1", board: "Manager" },
    { proc: "Proc-1", board: "Ops" },
    { proc: "Proc-2", board: "Alloc" },
    { proc: "Proc-2", board: "Manager" },
    { proc: "Proc-3", board: "Alloc" },
    { proc: "Proc-3", board: "Manager" }
